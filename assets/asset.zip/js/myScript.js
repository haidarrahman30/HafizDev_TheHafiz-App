function select(id) {
    window.location = id.value;
}

